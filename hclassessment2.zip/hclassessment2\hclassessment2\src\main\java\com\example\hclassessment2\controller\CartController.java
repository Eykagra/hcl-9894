package com.example.hclassessment2.controller;

import com.example.hclassessment2.model.Cart;
import com.example.hclassessment2.model.CartItem;
import com.example.hclassessment2.model.Customer;
import com.example.hclassessment2.model.Product;
import com.example.hclassessment2.repository.CartItemRepository;
import com.example.hclassessment2.repository.CartRepository;
import com.example.hclassessment2.repository.CustomerRepository;
import com.example.hclassessment2.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Optional;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/add/{customerId}/{productId}")
    public ResponseEntity<?> addToCart(
            @PathVariable Long customerId,
            @PathVariable Long productId,
            @RequestParam(name = "quantity", defaultValue = "1") Integer quantity,
            @RequestBody(required = false) CartItem requestItem) {

        if (requestItem != null && requestItem.getQuantity() != null) {
            quantity = requestItem.getQuantity();
        }

        if (quantity == null || quantity <= 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Quantity must be greater than zero");
        }

        Optional<Customer> customerOpt = customerRepository.findById(customerId);
        if (customerOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + customerId);
        }

        Optional<Product> productOpt = productRepository.findById(productId);
        if (productOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found with id: " + productId);
        }

        Product product = productOpt.get();
        Customer customer = customerOpt.get();

        Cart cart = cartRepository.findByCustomer_CustomerId(customerId)
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setCustomer(customer);
                    newCart.setCreatedDate(LocalDate.now());
                    return cartRepository.save(newCart);
                });

        Optional<CartItem> existingItemOpt = cartItemRepository.findByCart_CartIdAndProduct_ProductId(cart.getCartId(), productId);

        if (existingItemOpt.isPresent()) {
            CartItem existingItem = existingItemOpt.get();
            int newQuantity = existingItem.getQuantity() + quantity;
            if (newQuantity > product.getQuantity()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Requested quantity exceeds available product stock");
            }
            existingItem.setQuantity(newQuantity);
            existingItem.setPrice(product.getPrice());
            cartItemRepository.save(existingItem);
        } else {
            if (quantity > product.getQuantity()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Requested quantity exceeds available product stock");
            }
            CartItem newItem = new CartItem();
            newItem.setCart(cart);
            newItem.setProduct(product);
            newItem.setQuantity(quantity);
            newItem.setPrice(product.getPrice());
            cartItemRepository.save(newItem);
        }

        Cart updatedCart = cartRepository.findById(cart.getCartId()).orElse(cart);
        return ResponseEntity.status(HttpStatus.OK).body(updatedCart);
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<?> viewCart(@PathVariable Long customerId) {
        if (!customerRepository.existsById(customerId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + customerId);
        }

        return cartRepository.findByCustomer_CustomerId(customerId)
                .map(cart -> ResponseEntity.ok((Object) cart))
                .orElseGet(() -> {
                    Customer customer = customerRepository.findById(customerId).get();
                    Cart newCart = new Cart();
                    newCart.setCustomer(customer);
                    newCart.setCreatedDate(LocalDate.now());
                    Cart saved = cartRepository.save(newCart);
                    return ResponseEntity.ok((Object) saved);
                });
    }

    @PutMapping("/update/{cartItemId}")
    public ResponseEntity<?> updateCartQuantity(
            @PathVariable Long cartItemId,
            @RequestParam(name = "quantity", required = false) Integer quantity,
            @RequestBody(required = false) CartItem requestItem) {

        if (quantity == null && requestItem != null) {
            quantity = requestItem.getQuantity();
        }

        if (quantity == null || quantity <= 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Quantity must be greater than zero");
        }

        Optional<CartItem> cartItemOpt = cartItemRepository.findById(cartItemId);
        if (cartItemOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cart item not found with id: " + cartItemId);
        }

        CartItem cartItem = cartItemOpt.get();
        Product product = cartItem.getProduct();

        if (quantity > product.getQuantity()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Requested quantity exceeds available product stock");
        }

        cartItem.setQuantity(quantity);
        cartItem.setPrice(product.getPrice());
        CartItem savedItem = cartItemRepository.save(cartItem);
        return ResponseEntity.ok(savedItem);
    }

    @DeleteMapping("/remove/{cartItemId}")
    public ResponseEntity<?> removeProductFromCart(@PathVariable Long cartItemId) {
        Optional<CartItem> cartItemOpt = cartItemRepository.findById(cartItemId);
        if (cartItemOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cart item not found with id: " + cartItemId);
        }

        cartItemRepository.delete(cartItemOpt.get());
        return ResponseEntity.ok("Product removed from cart successfully!");
    }

    @DeleteMapping("/clear/{customerId}")
    public ResponseEntity<?> clearCart(@PathVariable Long customerId) {
        if (!customerRepository.existsById(customerId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + customerId);
        }

        Optional<Cart> cartOpt = cartRepository.findByCustomer_CustomerId(customerId);
        if (cartOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cart not found for customer id: " + customerId);
        }

        Cart cart = cartOpt.get();
        cart.getCartItems().clear();
        cartRepository.save(cart);
        return ResponseEntity.ok("Cart cleared successfully!");
    }
}

