package com.example.hclassessment2.controller;

import com.example.hclassessment2.model.Product;
import com.example.hclassessment2.repository.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @PostMapping
    public ResponseEntity<?> addProduct(@Valid @RequestBody Product product) {
        if (product.getProductName() == null || product.getProductName().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product name is mandatory");
        }
        if (product.getPrice() == null || product.getPrice() <= 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product price must be greater than zero");
        }
        if (product.getQuantity() == null || product.getQuantity() < 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product quantity cannot be negative");
        }
        Product savedProduct = productRepository.save(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProduct);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts(@RequestParam(required = false) String name) {
        if (name != null && !name.trim().isEmpty()) {
            return ResponseEntity.ok(productRepository.findByProductNameContainingIgnoreCase(name.trim()));
        }
        return ResponseEntity.ok(productRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(product -> ResponseEntity.ok((Object) product))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found with id: " + id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateProduct(@PathVariable Long id, @Valid @RequestBody Product productDetails) {
        return productRepository.findById(id)
                .map(existingProduct -> {
                    if (productDetails.getProductName() != null) {
                        if (productDetails.getProductName().trim().isEmpty()) {
                            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body((Object) "Product name cannot be blank");
                        }
                        existingProduct.setProductName(productDetails.getProductName());
                    }
                    if (productDetails.getDescription() != null) {
                        existingProduct.setDescription(productDetails.getDescription());
                    }
                    if (productDetails.getPrice() != null) {
                        if (productDetails.getPrice() <= 0) {
                            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body((Object) "Product price must be greater than zero");
                        }
                        existingProduct.setPrice(productDetails.getPrice());
                    }
                    if (productDetails.getQuantity() != null) {
                        if (productDetails.getQuantity() < 0) {
                            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body((Object) "Product quantity cannot be negative");
                        }
                        existingProduct.setQuantity(productDetails.getQuantity());
                    }
                    if (productDetails.getCategory() != null) {
                        existingProduct.setCategory(productDetails.getCategory());
                    }
                    Product updatedProduct = productRepository.save(existingProduct);
                    return ResponseEntity.ok((Object) updatedProduct);
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found with id: " + id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(product -> {
                    productRepository.delete(product);
                    return ResponseEntity.ok().body("Product deleted successfully!");
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found with id: " + id));
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String category) {
        List<Product> products = productRepository.findByCategoryIgnoreCase(category);
        return ResponseEntity.ok(products);
    }

    @GetMapping("/search")
    public ResponseEntity<List<Product>> searchProductsByName(@RequestParam(name = "name", defaultValue = "") String name) {
        return ResponseEntity.ok(productRepository.findByProductNameContainingIgnoreCase(name.trim()));
    }

    @GetMapping("/search/{name}")
    public ResponseEntity<List<Product>> searchProductsByPathName(@PathVariable String name) {
        return ResponseEntity.ok(productRepository.findByProductNameContainingIgnoreCase(name.trim()));
    }
}
