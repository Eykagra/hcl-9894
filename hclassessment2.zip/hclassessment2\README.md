# Online Shopping Application

Spring Boot REST API for an online shopping platform with customer management, product browsing, cart handling, and order processing.

---

## Prerequisites
- Java 17 or higher
- MySQL Server
- Maven (or use included `./mvnw`)

---

## Database Setup

1. Start your MySQL service.
2. Create the database:
```sql
CREATE DATABASE shopping_db;
```
3. Update `src/main/resources/application.properties` if your MySQL username or password differs:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/shopping_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=root
```
You can also run the SQL script located at `src/main/resources/schema.sql` to initialize tables manually.

---

## Running the Application

Using terminal:
```bash
./mvnw spring-boot:run
```
On Windows:
```cmd
mvnw.cmd spring-boot:run
```

The application runs on `http://localhost:8080`.

---

## API Endpoints & Examples

### 1. Customer APIs

- **Register Customer**: `POST /api/customers/register`
  - Request:
    ```json
    {
      "customerName": "John Doe",
      "email": "john@example.com",
      "password": "password123",
      "mobile": "9876543210",
      "city": "New York"
    }
    ```
  - Success Response (`201 Created`):
    ```json
    {
      "customerId": 1,
      "customerName": "John Doe",
      "email": "john@example.com",
      "password": "password123",
      "mobile": "9876543210",
      "city": "New York"
    }
    ```
  - Validation Failure (`400 Bad Request`):
    ```text
    Mobile number must contain 10 digits
    ```

- **Get All Customers**: `GET /api/customers`
- **Get Customer by ID**: `GET /api/customers/{id}`
- **Update Customer**: `PUT /api/customers/{id}`
- **Delete Customer**: `DELETE /api/customers/{id}`

---

### 2. Product APIs

- **Add Product**: `POST /api/products`
  - Request:
    ```json
    {
      "productName": "Wireless Mouse",
      "description": "Ergonomic 2.4G mouse",
      "price": 25.50,
      "quantity": 100,
      "category": "Electronics"
    }
    ```
  - Success Response (`201 Created`)
  - Failure (`400 Bad Request` if price <= 0 or quantity < 0):
    ```text
    Product price must be greater than zero
    ```

- **Get All Products / Filter by Name**: `GET /api/products` or `GET /api/products?name=Mouse`
- **Search Products**: `GET /api/products/search?name=Mouse`
- **Get Products by Category**: `GET /api/products/category/Electronics`
- **Get Product by ID**: `GET /api/products/{id}`
- **Update Product**: `PUT /api/products/{id}`
- **Delete Product**: `DELETE /api/products/{id}`

---

### 3. Shopping Cart APIs

- **Add to Cart**: `POST /api/cart/add/{customerId}/{productId}?quantity=2`
  - Success Response (`200 OK`):
    ```json
    {
      "cartId": 1,
      "customer": { "customerId": 1, "customerName": "John Doe" },
      "createdDate": "2026-11-03",
      "cartItems": [
        {
          "cartItemId": 1,
          "product": { "productId": 1, "productName": "Wireless Mouse", "price": 25.50 },
          "quantity": 2,
          "price": 25.50
        }
      ],
      "cartTotal": 51.0
    }
    ```
  - Failure (`400 Bad Request`):
    ```text
    Requested quantity exceeds available product stock
    ```

- **View Cart**: `GET /api/cart/{customerId}`
- **Update Cart Item Quantity**: `PUT /api/cart/update/{cartItemId}?quantity=3`
- **Remove Cart Item**: `DELETE /api/cart/remove/{cartItemId}`
- **Clear Cart**: `DELETE /api/cart/clear/{customerId}`

---

### 4. Order APIs

- **Place Order**: `POST /api/orders/place/{customerId}`
  - Moves cart items to order, deducts stock, sets status to `PLACED`, and clears cart.
- **Order History**: `GET /api/orders/{customerId}`
- **Cancel Order**: `PUT /api/orders/cancel/{orderId}`
  - Restores stock and marks status as `CANCELLED`.

