package com.example.hclassessment2.controller;

import com.example.hclassessment2.model.Customer;
import com.example.hclassessment2.repository.CustomerRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @PostMapping("/register")
    public ResponseEntity<?> registerCustomer(@Valid @RequestBody Customer customer) {
        if (customer.getCustomerName() == null || customer.getCustomerName().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Customer name cannot be blank");
        }
        if (customer.getEmail() == null || customer.getEmail().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email cannot be blank");
        }
        if (customerRepository.findByEmail(customer.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is already registered");
        }
        if (customer.getMobile() == null || !customer.getMobile().matches("^\\d{10}$")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Mobile number must contain 10 digits");
        }
        Customer savedCustomer = customerRepository.save(customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedCustomer);
    }

    @GetMapping
    public ResponseEntity<List<Customer>> getAllCustomers() {
        return ResponseEntity.ok(customerRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getCustomerById(@PathVariable Long id) {
        return customerRepository.findById(id)
                .map(customer -> ResponseEntity.ok((Object) customer))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateCustomer(@PathVariable Long id, @Valid @RequestBody Customer customerDetails) {
        return customerRepository.findById(id)
                .map(existingCustomer -> {
                    if (customerDetails.getCustomerName() != null) {
                        if (customerDetails.getCustomerName().trim().isEmpty()) {
                            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body((Object) "Customer name cannot be blank");
                        }
                        existingCustomer.setCustomerName(customerDetails.getCustomerName());
                    }
                    if (customerDetails.getEmail() != null) {
                        Optional<Customer> customerWithEmail = customerRepository.findByEmail(customerDetails.getEmail());
                        if (customerWithEmail.isPresent() && !customerWithEmail.get().getCustomerId().equals(id)) {
                            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body((Object) "Email is already in use by another customer");
                        }
                        existingCustomer.setEmail(customerDetails.getEmail());
                    }
                    if (customerDetails.getMobile() != null) {
                        if (!customerDetails.getMobile().matches("^\\d{10}$")) {
                            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body((Object) "Mobile number must contain 10 digits");
                        }
                        existingCustomer.setMobile(customerDetails.getMobile());
                    }
                    if (customerDetails.getPassword() != null) {
                        existingCustomer.setPassword(customerDetails.getPassword());
                    }
                    if (customerDetails.getCity() != null) {
                        existingCustomer.setCity(customerDetails.getCity());
                    }
                    Customer updatedCustomer = customerRepository.save(existingCustomer);
                    return ResponseEntity.ok((Object) updatedCustomer);
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable Long id) {
        return customerRepository.findById(id)
                .map(customer -> {
                    customerRepository.delete(customer);
                    return ResponseEntity.ok().body("Customer deleted successfully!");
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + id));
    }
}
