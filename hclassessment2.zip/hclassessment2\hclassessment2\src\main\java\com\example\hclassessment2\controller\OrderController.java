package com.example.hclassessment2.controller;

import com.example.hclassessment2.model.*;
import com.example.hclassessment2.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private CustomerOrderRepository customerOrderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/place/{customerId}")
    @Transactional
    public ResponseEntity<?> placeOrder(@PathVariable Long customerId) {
        Optional<Customer> customerOpt = customerRepository.findById(customerId);
        if (customerOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + customerId);
        }

        Optional<Cart> cartOpt = cartRepository.findByCustomer_CustomerId(customerId);
        if (cartOpt.isEmpty() || cartOpt.get().getCartItems().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Cart is empty");
        }

        Cart cart = cartOpt.get();
        for (CartItem item : cart.getCartItems()) {
            Product prod = item.getProduct();
            if (item.getQuantity() > prod.getQuantity()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Insufficient stock for product: " + prod.getProductName());
            }
        }

        Customer customer = customerOpt.get();
        CustomerOrder order = new CustomerOrder();
        order.setCustomer(customer);
        order.setOrderDate(LocalDateTime.now());
        order.setOrderStatus("PLACED");

        double total = 0.0;
        for (CartItem item : cart.getCartItems()) {
            Product prod = item.getProduct();
            prod.setQuantity(prod.getQuantity() - item.getQuantity());
            productRepository.save(prod);

            OrderItem orderItem = new OrderItem();
            orderItem.setCustomerOrder(order);
            orderItem.setProduct(prod);
            orderItem.setQuantity(item.getQuantity());
            orderItem.setPrice(item.getPrice());
            order.getOrderItems().add(orderItem);

            total += item.getPrice() * item.getQuantity();
        }

        order.setTotalAmount(total);
        CustomerOrder savedOrder = customerOrderRepository.save(order);

        cart.getCartItems().clear();
        cartRepository.save(cart);

        return ResponseEntity.status(HttpStatus.CREATED).body(savedOrder);
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<?> getOrderHistory(@PathVariable Long customerId) {
        if (!customerRepository.existsById(customerId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with id: " + customerId);
        }
        List<CustomerOrder> orders = customerOrderRepository.findByCustomer_CustomerId(customerId);
        return ResponseEntity.ok(orders);
    }

    @PutMapping("/cancel/{orderId}")
    @Transactional
    public ResponseEntity<?> cancelOrder(@PathVariable Long orderId) {
        Optional<CustomerOrder> orderOpt = customerOrderRepository.findById(orderId);
        if (orderOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Order not found with id: " + orderId);
        }

        CustomerOrder order = orderOpt.get();
        if ("CANCELLED".equalsIgnoreCase(order.getOrderStatus())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Order is already cancelled");
        }

        for (OrderItem item : order.getOrderItems()) {
            Product prod = item.getProduct();
            prod.setQuantity(prod.getQuantity() + item.getQuantity());
            productRepository.save(prod);
        }

        order.setOrderStatus("CANCELLED");
        CustomerOrder updatedOrder = customerOrderRepository.save(order);
        return ResponseEntity.ok(updatedOrder);
    }
}

